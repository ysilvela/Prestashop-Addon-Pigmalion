<?php

// Empty translation file to get the English language showing on prestashop addons page as a translation.
// The module source language is also English theirs no need to duplicate the translations here and maintain them.